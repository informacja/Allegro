#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
float pozX=100, pozY=100;int rozmiar = 128;
int main()
{
    al_init();
    al_install_mouse();
    al_install_keyboard();
    al_init_image_addon();
    ALLEGRO_MOUSE_STATE myszka;
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_TIMER       *zegar;   // ( timer )
    ALLEGRO_EVENT_QUEUE *kolejka; // ( queue )
    bool odswiez = true;
    //al_set_new_display_flags( ALLEGRO_FULLSCREEN );
    ALLEGRO_DISPLAY *okno = al_create_display(800,600);
    al_set_window_title(okno, "Przenoszenie");
    ALLEGRO_BITMAP *box= al_load_bitmap("media/domek128x128.png");
    int klik=0;
    zegar   = al_create_timer(1.0 / 60);
    kolejka = al_create_event_queue();

    al_register_event_source( kolejka, al_get_mouse_event_source());
    al_register_event_source( kolejka, al_get_keyboard_event_source());
    al_register_event_source( kolejka, al_get_display_event_source(okno));
    al_register_event_source( kolejka, al_get_timer_event_source  (zegar));

    al_start_timer(zegar);
    ALLEGRO_EVENT zdarzenie;
    while (1)
  {
         al_get_mouse_state(&myszka);
         al_wait_for_event(kolejka, &zdarzenie);

        if (zdarzenie.type == ALLEGRO_EVENT_DISPLAY_CLOSE)      { break; }
        if (zdarzenie.type == ALLEGRO_EVENT_KEY_UP)             { if (zdarzenie.keyboard.keycode == ALLEGRO_KEY_ESCAPE) break; }
        if (zdarzenie.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN)  { klik = zdarzenie.mouse.button; }
        if (zdarzenie.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP  )  { klik = 0; }
        if (zdarzenie.type == ALLEGRO_EVENT_MOUSE_AXES       )  {
        if (myszka.x>=pozX && myszka.x<=pozX+rozmiar && myszka.y>=pozY && myszka.y<=pozY+rozmiar &&  klik &1 )
          {
           float x = zdarzenie.mouse.dx ;
           float y = zdarzenie.mouse.dy ;
           pozX += x ;
           pozY += y ;
          }
        }
         if (odswiez)
          {
             al_clear_to_color(al_map_rgb(128,128,128));
             al_draw_bitmap (box, pozX, pozY, 0);
             al_flip_display();
          }
          if (zdarzenie.type == ALLEGRO_EVENT_TIMER) { odswiez = true; } else odswiez = false;
  }
     return 0;
}