#include <ctime>
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>

int Tab_Kafli[15][20] =
{
    { 4,14,14,14,10,14,14,14,14,14,14,14,14,14,14,14,14,14,14, 5},
    {15, 3, 3, 3,15, 3, 3, 3, 3, 3, 3, 3, 3, 3,13,13,13,13,13,15},
    {15, 3, 3, 3,15, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 3, 2, 2, 2, 3, 3, 2, 2, 2, 2, 2, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 3, 3, 3, 2, 3, 2, 3, 3, 3, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 3, 3, 3, 2, 3, 2, 3, 3, 3, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 3, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 3, 3, 3, 2, 3, 3, 3, 3, 3, 2, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 3, 3, 3, 2, 3, 3, 3, 3, 3, 2, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 3, 3, 3, 2, 3, 2, 3, 3, 3, 2, 3, 3,15},
    {15, 3, 3, 3,15, 3, 2, 3, 3, 3, 2, 3, 3, 2, 2, 2, 3, 3, 3,15},
    { 7,14,14,14,11,14,14,14,14,14,14,14,14,14,14,14,14,14,14, 6}
};

int main()
{
    al_init();
    al_init_image_addon();
    ALLEGRO_DISPLAY * okno     = al_create_display(800,600);
    ALLEGRO_BITMAP  * kafelki  = al_load_bitmap("media/kafelki.png");
    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(okno));
    ALLEGRO_EVENT event;
    while(1)
    {
        al_get_next_event(event_queue, &event);
        if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
        {
            return 0;
        }

        al_clear_to_color(al_map_rgb(255,255,0));
        for (int y=0 ; y < 15 ; y++ )
            for (int x=0 ; x < 20 ; x++ )
                al_draw_bitmap_region(kafelki,40*Tab_Kafli[y][x], 0,40,40,x*40, y*40,0);
        al_flip_display();
        al_rest(0.005);//pauza
    }
    al_destroy_bitmap(kafelki);
    al_destroy_display(okno);
    al_destroy_event_queue(event_queue);

    return 0;
}
