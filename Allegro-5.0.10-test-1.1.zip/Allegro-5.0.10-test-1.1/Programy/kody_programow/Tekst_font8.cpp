#include <allegro5/allegro.h>            // Podstawowy nag³ówek allegro
#include <allegro5/allegro_font.h> // Plik nag³ówkowy dodaj¹cy czcionki
 int main()
{
    al_init();
    al_init_font_addon();          // inicjowanie czcionek
    al_install_keyboard();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_DISPLAY *okno  = al_create_display(320,240);
    ALLEGRO_FONT    *font8 = al_create_builtin_font();  //  wskaŸnik do czcionki

    unsigned char znak=32;
    while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
      al_get_keyboard_state(&klawiatura);
      al_clear_to_color(al_map_rgb(0,0,0));
      al_draw_text (font8,al_map_rgb(255,255,255),100,100,0,"Jakiś tam tekst.");
       for(unsigned char y=0; y<14; y++)
       for(unsigned char x=0; x<16; x++)
       al_draw_textf (font8,al_map_rgb(255,255,255),8*x,8*y,0,"%c",znak++); znak=32;
      al_flip_display();
    }
    al_destroy_font(font8);
    al_destroy_display(okno);
    return 0;
}
