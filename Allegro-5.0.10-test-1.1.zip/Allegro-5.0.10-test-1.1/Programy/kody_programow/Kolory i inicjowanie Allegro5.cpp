#include <allegro5/allegro.h>
#include <allegro5/allegro_native_dialog.h>
ALLEGRO_DISPLAY *okno = NULL;
int main()
{
    if(!al_init())
    {
        al_show_native_message_box(okno, "Błąd", "hej no co?",
                                   "Nie mogę zainicjować Allegro5!\n weź się ogarnij!",
                                   NULL, ALLEGRO_MESSAGEBOX_ERROR);
        return 0;
    }
    al_set_new_window_position(20,30);
    al_set_new_display_flags(ALLEGRO_WINDOWED);
    okno = al_create_display( 320, 240);
    if(!okno)
    {
        al_show_native_message_box(okno, "Błąd", "NULL",
                                   "Nie mogę utworzyć okna!",
                                   NULL, ALLEGRO_MESSAGEBOX_ERROR);
        return 0;
    }
    al_set_window_title( okno,"Kolory i inicjowanie Allegro5");
    ALLEGRO_BITMAP *kwadrat, *prostokat= NULL;
    kwadrat  = al_create_bitmap(50,50);
    prostokat= al_create_bitmap(100,50);
    if(!kwadrat or !prostokat)
    {
        al_show_native_message_box(okno, "Błąd", "Coś nie tak",
                                   "Nie mogę utworzyć bitmap!",
                                   NULL, ALLEGRO_MESSAGEBOX_ERROR);
        return 0;
    }
    al_set_target_bitmap(kwadrat);
    al_clear_to_color(al_map_rgb(0,255,0));
    al_set_target_bitmap(prostokat);
    al_clear_to_color(al_map_rgb(255,0,0));
    al_set_target_bitmap(al_get_backbuffer(okno));
    al_clear_to_color(al_map_rgb_f(1.0,1.0,0.0));
    al_draw_bitmap(kwadrat, 100, 100, 0);
    al_draw_bitmap(prostokat,125, 125, 0);
    al_flip_display();
    al_rest(5.0);
    al_destroy_display(okno);
    return 0;
}
