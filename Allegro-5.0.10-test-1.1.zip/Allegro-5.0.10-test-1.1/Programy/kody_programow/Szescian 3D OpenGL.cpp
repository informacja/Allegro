// autor Gabes
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_opengl.h>
#include <GL/glu.h>
ALLEGRO_DISPLAY *okno=NULL;
float obroty;

void Viewport()
{    glViewport (0, 0, (GLsizei)al_get_display_width(okno), (GLsizei)al_get_display_height(okno));
     glMatrixMode(GL_PROJECTION);
     glLoadIdentity();
     gluPerspective( 45.0f, (GLfloat)al_get_display_width(okno)/(GLfloat)al_get_display_height(okno),0.1f,100.0f);
     glMatrixMode(GL_MODELVIEW);
  // glLoadIdentity();
}

void init(void)
{
    glClearColor(0.5, 0.5, 0.5, 0.0);/// kolor ekranu
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glTranslatef(0, 0, -5);
}

void klatka(void)
{
  //glPushMatrix();
  //glScalef(0.5,0.5,0.5);
    glRotatef(obroty, 1, 1, 1);
    glColor3f(1.0,1.0,1.0);
    glBegin ( GL_QUADS );
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
     glEnd();
}
int main(int argc, char **argv)
{
     al_init();
     al_init_image_addon();
     al_install_keyboard();
     ALLEGRO_KEYBOARD_STATE key_state;
     al_set_new_display_flags(ALLEGRO_RESIZABLE | ALLEGRO_OPENGL);
     okno = al_create_display(640,480);
     ALLEGRO_BITMAP * box = al_load_bitmap("media/klatka.png");
     glEnable(GL_DEPTH_TEST);
     glAlphaFunc(GL_GREATER, 0.5);
     glEnable(GL_ALPHA_TEST);
  //   glEnable(GL_BLEND);
  //   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
     glBindTexture(GL_TEXTURE_2D, al_get_opengl_fbo (box));
     glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
     glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);

     glEnable(GL_TEXTURE_2D);
     glShadeModel(GL_SMOOTH);
     //glShadeModel(GL_FLAT);
     glEnable(GL_POLYGON_SMOOTH);

     ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
     al_register_event_source(event_queue, al_get_display_event_source(okno));
     ALLEGRO_EVENT ev;
    while(!al_key_down(&key_state, ALLEGRO_KEY_ESCAPE))
     {
      al_get_next_event(event_queue, &ev); if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { return 0; }
      al_get_keyboard_state(&key_state);
       if (ev.type == ALLEGRO_EVENT_DISPLAY_RESIZE) {al_acknowledge_resize(okno);}
      obroty+=0.5;
      Viewport();
      init();
      klatka();

      al_flip_display();
     }
      al_destroy_display(okno);
    return 0;
}
