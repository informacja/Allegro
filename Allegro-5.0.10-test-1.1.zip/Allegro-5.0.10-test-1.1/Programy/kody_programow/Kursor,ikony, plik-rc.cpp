/// Aby wczytać ikone do pliku wykonywalnego Kursor,ikony,plik-rc.exe
/// do projektu dodajemy plik Projekt.rc
/// o zawartości: IKONA ICON "media/ikona.ico"

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_opengl.h>

int main()
{
    al_init();
    al_install_mouse();
    al_install_keyboard();
    al_init_image_addon();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_MOUSE_STATE  myszka;
    al_set_new_display_flags(ALLEGRO_OPENGL);
    ALLEGRO_DISPLAY *okno   = al_create_display( 400, 300);
    ALLEGRO_BITMAP  *ikonka = al_load_bitmap("media/Allegro5.png");
    ALLEGRO_BITMAP  *kursor = al_load_bitmap("media/kursor.png");
    ALLEGRO_MOUSE_CURSOR * cursor = al_create_mouse_cursor( kursor, 0, 0);
    al_set_display_icon(okno, ikonka);
    ALLEGRO_EVENT zdarzenie;
    ALLEGRO_EVENT_QUEUE *kolejka = al_create_event_queue();
    al_register_event_source(kolejka, al_get_display_event_source(okno));

    while(!al_key_down(&klawiatura , ALLEGRO_KEY_ESCAPE))
    {
        al_get_next_event(kolejka, &zdarzenie);
        if(zdarzenie.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
        {
            return 0;
        }
        al_get_keyboard_state (&klawiatura);
        al_get_mouse_state    (&myszka);
        al_clear_to_color(al_map_rgb( 0, 128, 0));
        al_set_mouse_cursor(okno, cursor );//wyświetlanie kursora
        al_flip_display();
    }
    return 0;
}
