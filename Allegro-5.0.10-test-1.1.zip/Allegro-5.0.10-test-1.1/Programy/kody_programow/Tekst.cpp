#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_primitives.h>
#include<string>
using namespace std;
int wys     =  18;
int ile     =  22;
int SzerEkr = 800; ///int WysEkr = wys * ile;
int TabLiczby [3][4] =
 {
    { 1, 4, 1, 0 },
    { 1, 7, 9, 2 },
    { 6, 3, 5, 8 }
 };
const char *imie [] = {"Monika","Krzysztof","Janek","Grzegorz","Małgosia","Zenek","Karolek","Pokemon","Łukasz","Mariola",
                 "","","","","","","","","","20","21","22"};
string imiona[]= {"Andrzej","Ewa","Adam","Sylwester","Kacper","Melchior","Baltazar","Walenty","Donald","Goofy","Mickey",
                          "Jaźń","ooo","xxx","zzz","abc","ktoś","Makumba","Irena","Wiesiek","21","22"};

ALLEGRO_USTR * Tekst  = al_ustr_new ("Mamo, Tato, ja piszę w c++ !!!"); /// Kodowanie UTF8 w C::B
ALLEGRO_USTR * tekstS = al_ustr_new ("Siostro,bracie ja naprawdę piszę w c++!!!");
ALLEGRO_USTR * tekstl = al_ustr_new ("aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźż");
ALLEGRO_USTR * tekstL = al_ustr_new ("AĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUVWXYZŹŻ");
ALLEGRO_USTR * tekstZ = al_ustr_new ("01234567890.,:-+*/!@#$%^&*()=;");
int main()
{
    al_init();
    al_init_image_addon();
    al_init_font_addon();
    al_init_ttf_addon();
    al_install_keyboard();
    al_init_primitives_addon();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    al_set_new_display_flags(ALLEGRO_WINDOWED|ALLEGRO_RESIZABLE);
    ALLEGRO_DISPLAY *okno = al_create_display(SzerEkr,600);
	al_set_window_title(okno,"Czcionka Bitmapowa i TTF.");

    ALLEGRO_FONT  *font_png    = al_load_bitmap_font("media/courier_16.png");
    ALLEGRO_FONT * font8       = al_create_builtin_font();
    ALLEGRO_FONT * font_w      = al_load_ttf_font("media/courbd.ttf",wys,0 );
    ALLEGRO_FONT * font_ttf    = al_load_ttf_font("media/courbd.ttf",21,ALLEGRO_TTF_NO_KERNING); /*lub  | ALLEGRO_TTF_MONOCHROME*/ /*brak*/
    ALLEGRO_FONT * font_ttf_16 = al_load_ttf_font("media/courbd.ttf",16, 4);
    ALLEGRO_FONT * font_ttf_24 = al_load_ttf_font("media/courbd.ttf",24, 0);
    ALLEGRO_FONT * font_ttf_30 = al_load_ttf_font("media/courbd.ttf",30, 0);
    ALLEGRO_FONT * font_ttf1   = al_load_ttf_font("media/FLAMES.ttf",32,ALLEGRO_TTF_NO_KERNING/*|2|1*/);//ALLEGRO_TTF_NO_AUTOHINT

    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(okno));
    ALLEGRO_EVENT ev;

    while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_next_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { return 0; }
    //  if(ev.type == ALLEGRO_EVENT_DISPLAY_RESIZE){al_acknowledge_resize(okno);}
        al_get_keyboard_state(&klawiatura);
        al_clear_to_color(al_map_rgb(108,108,108));

        al_draw_ustr(font_ttf,al_map_rgb (255,255,  0), 5,  1, 0,Tekst);
        al_draw_ustr(font_ttf,al_map_rgb (255,  0,  0), 5, 20, 0,tekstl);
        al_draw_ustr(font_ttf,al_map_rgb (  0,255,  0), 5, 40, 0,tekstL);
        al_draw_ustr(font_ttf,al_map_rgba(  0,  0,255,255), 5,60, 0,tekstZ);
        al_draw_ustr(font_ttf,al_map_rgb (255,255,255), 5,100, 0,tekstS);
        al_draw_textf(font_ttf_16,al_map_rgb(255,255,255),  0, 142,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_textf(font_ttf_24,al_map_rgb(255,255,255),  0, 158,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_textf(font_ttf_30,al_map_rgb(255,255,255),  0, 180,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_text (font_ttf_30,al_map_rgb(255,255,  0), 45, 220,0,"I zażółć gęślą jaźń.");

        al_draw_textf(font_ttf1,al_map_rgba( 10,10,10,255),314, 544,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_textf(font_ttf1,al_map_rgb (200, 0,     0),310, 540,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");

        al_draw_text (font8,al_map_rgb(200,200,0),10,585,0,"A cóż to za malutka czcionka?");

         for ( int y = 0; y < 3; y++)  {
         for ( int x = 0; x < 4; x++) {
          al_draw_textf(font_png,al_map_rgb(  0,  0,255),  700+x*16, 450+y*16, 0, "%d",TabLiczby[y][x]);
         }
        };

        al_draw_filled_rectangle(540, 10,785, 10+wys*ile,al_map_rgb_f( 0.0, 0.0, 0.0));
        for ( int licz = 0; licz < ile; licz++){
        al_draw_textf(font_w,al_map_rgb(255,255,255), 550, 10+licz*wys,0,"%2d. %s", licz+1,imie[licz]);  }

        al_draw_rectangle( 10, 300,300,576, al_map_rgb (0,0,255), 2);
        al_draw_line     ( 54, 300, 54,576, al_map_rgb (0,0,255), 2);
        al_draw_line     (100, 300,100,576, al_map_rgb (0,0,255), 2);

    for (int licz = 0; licz < 12; licz++)
        al_draw_line( 10,300+(licz*23),300,300+(licz*23),al_map_rgb(0,0,255),2);
        al_draw_text(font_w,al_map_rgb(255,255,255), 15, 276,0,"Lp. bajty    IMIE");
        for ( int licz = 0; licz < 12; licz++) {
        al_draw_textf(font_png, al_map_rgb (255,255,  0),  15,300+licz*23, 0,
                             "%2i %2d   %s",licz+1,imiona[licz].size(),imiona[licz].c_str());     };

        al_flip_display();
        al_rest(0.005);//pauza
    }
	al_destroy_font(font8);
	al_destroy_font(font_ttf_16);
	al_destroy_font(font_ttf_24);
    al_destroy_font(font_ttf_30);
    al_destroy_font(font_png);
    al_destroy_display(okno);
    return 0;
}
