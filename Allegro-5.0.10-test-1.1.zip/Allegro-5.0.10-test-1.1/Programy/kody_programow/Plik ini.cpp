#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
ALLEGRO_CONFIG *config;
int vsync, fullscreen, frequency, szer, wys, txt_x, txt_y;

static int option(ALLEGRO_CONFIG *config, char const *name, int v)
{
   char const *value;
   char str[256];
   value = al_get_config_value(config, "settings", name);
   if (value)
      v = strtol(value, NULL, 0);
  // sprintf(str, "%d", v);
   al_set_config_value(config, "settings", name, str);
   return v;
}
int main()
{
    al_init();
    al_init_image_addon();
    al_init_font_addon();
    al_init_ttf_addon();
    al_install_keyboard();
    config     = al_load_config_file("media/plik_ini.ini"); /// zmiany rozdzielczosci, fullscreen itd. dokonujemy w pliku ini
    fullscreen = option(config, "fullscreen", 0);
    frequency  = option(config, "frequency" , 0);
    vsync      = option(config, "vsync"     , 0);
    szer       = option(config, "szer"      , 0);
    wys        = option(config, "wys"       , 0);

   if (vsync)al_set_new_display_option(ALLEGRO_VSYNC, vsync, ALLEGRO_SUGGEST);//  true
   if (fullscreen) al_set_new_display_flags(ALLEGRO_FULLSCREEN);
   if (frequency) al_set_new_display_refresh_rate(frequency);
    ALLEGRO_KEYBOARD_STATE klawiatura;
   // al_set_new_display_flags(ALLEGRO_WINDOWED|ALLEGRO_RESIZABLE);
    ALLEGRO_DISPLAY *okno = al_create_display(szer,wys);
    ALLEGRO_FONT * font8 = al_create_builtin_font();

	al_set_window_title(okno,"ini");

    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(okno));
    ALLEGRO_EVENT ev;

    while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_next_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { return 0; }
    //  if(ev.type == ALLEGRO_EVENT_DISPLAY_RESIZE){al_acknowledge_resize(okno);}
        al_get_keyboard_state(&klawiatura);
        al_clear_to_color(al_map_rgb(128,128,128));

        al_draw_textf (font8,al_map_rgb(0,0,0),10,10,0,"rozmiar okna - x= %i, y= %i",szer,wys);
        al_flip_display();
    }
	al_destroy_font(font8);
    al_destroy_display(okno);
    return 0;
}
