#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_image.h> // zawsze dodajemy plik nag³ówkowy bitmap
int main()
{
    al_init();
    al_init_font_addon();
    al_init_image_addon(); // bezwzglêdnie inicjowaæ bitmapy
    al_install_keyboard();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    al_set_new_display_flags(ALLEGRO_WINDOWED);
    ALLEGRO_DISPLAY *okno     = al_create_display(400,150);
    ALLEGRO_FONT    *font_png = al_load_bitmap_font("media/courier_16.png");//  wskaŸnik do czcionki bitmapowej
     while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_keyboard_state(&klawiatura);
        al_clear_to_color(al_map_rgb_f(0.5,0.5,0.5));
        al_draw_textf(font_png,al_map_rgb(255,255,255), 20, 20,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR" !");
        al_draw_textf(font_png,al_map_rgb(255,255,  0), 80, 60,0,"I zażółć gęślą jaźń.");
        al_flip_display();
    }
    al_destroy_font(font_png);
    al_destroy_display(okno);
    return 0;
}
