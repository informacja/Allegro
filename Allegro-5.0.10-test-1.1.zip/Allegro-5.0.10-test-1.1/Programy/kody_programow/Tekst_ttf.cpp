#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>// zawsze dodajemy plik nagłówkowy ttf
ALLEGRO_USTR * Tekst  = al_ustr_new ("Mamo, Tato, ja piszę w c++ !!!"); // Kodowanie UTF8 w C::B
int main()
{
    al_init();
    al_init_font_addon();
    al_init_ttf_addon(); // pamiętaj !
    al_install_keyboard();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    al_set_new_display_flags(ALLEGRO_WINDOWED);
    ALLEGRO_DISPLAY *okno     = al_create_display(450,300);
    al_set_window_title(okno,"Font TTF");
    ALLEGRO_FONT * font_ttf    = al_load_ttf_font("media/courbd.ttf",24, 0);//  wskaźnik do czcionki ttf
    ALLEGRO_FONT * font_ttf_16 = al_load_ttf_font("media/courbd.ttf",16, 1);
    ALLEGRO_FONT * font_ttf_24 = al_load_ttf_font("media/courbd.ttf",24, 2);
    ALLEGRO_FONT * font_ttf_30 = al_load_ttf_font("media/courbd.ttf",30, 4);
     while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_keyboard_state(&klawiatura);
        al_clear_to_color(al_map_rgb_f(0.5,0.5,0.5));
        al_draw_ustr(font_ttf,al_map_rgb (0,0,255), 15, 40, 0,Tekst);
        al_draw_textf(font_ttf_16,al_map_rgb(255,255,255), 10, 142,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_textf(font_ttf_24,al_map_rgb(255,255,255), 10, 158,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_textf(font_ttf_30,al_map_rgb(255,255,255), 10, 180,0,"Witaj w Allegro %s",ALLEGRO_VERSION_STR"!");
        al_draw_text (font_ttf_30,al_map_rgb(255,255,  0), 55, 220,0,"I zażółć gęślą jaźń.");
        al_flip_display();
    }
    al_destroy_font(font_ttf);
    al_destroy_font(font_ttf_16);
    al_destroy_font(font_ttf_24);
    al_destroy_font(font_ttf_30);
    al_destroy_display(okno);
    return 0;
}
