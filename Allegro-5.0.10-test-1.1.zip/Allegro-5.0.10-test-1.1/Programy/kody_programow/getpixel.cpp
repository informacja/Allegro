#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>

int main()
{
    al_init();
    al_init_image_addon();
    al_init_font_addon();
    al_install_mouse();
    al_install_keyboard();
    ALLEGRO_MOUSE_STATE myszka;
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_DISPLAY *okno = al_create_display(420,340);
	ALLEGRO_FONT    *font_png  = al_load_bitmap_font( "media/Courier_16.png" );
    ALLEGRO_BITMAP  *bitmapa   = al_load_bitmap( "media/widok.png" );
    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(okno));
    ALLEGRO_EVENT event;
    ///ALLEGRO_COLOR kolor;
    unsigned char r, g, b, a;
    while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_next_event(event_queue, &event);
       if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) {return 0;}
        al_get_mouse_state(&myszka);
        al_get_keyboard_state(&klawiatura);
        al_unmap_rgba( al_get_pixel (al_get_backbuffer(okno),myszka.x,myszka.y),&r,&g,&b,&a); // odczyt
        al_clear_to_color(al_map_rgb(126,127,128));
        al_draw_bitmap (bitmapa,50,60,0);
       /// kolor = al_get_pixel (al_get_backbuffer(okno),myszka.x,myszka.y);

        // al_unmap_rgba( ... tu jesli nie chcemy odczytu kolorow z tekstu.
        al_draw_textf(font_png,al_map_rgb(255,255,255), 0, 4,0, "r= %3d, g= %3d, b= %3d, a= %3d",r,g,b,a);
        al_draw_textf(font_png,al_map_rgb(255,255,  0),16,34,0, "myszka.x=%3d myszka.y=%3d",myszka.x,myszka.y);
        al_flip_display();
    }
    al_destroy_font(font_png);
    al_destroy_display(okno);
    return 0;
}
