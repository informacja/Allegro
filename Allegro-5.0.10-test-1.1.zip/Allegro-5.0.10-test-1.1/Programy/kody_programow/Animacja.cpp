#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_audio.h>
#include <allegro5/allegro_acodec.h>
int main()
{
    al_init();
    al_install_keyboard();
    al_init_image_addon();
    al_install_audio();
    al_init_acodec_addon();
    al_reserve_samples(2);
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_DISPLAY * okno    = al_create_display(255, 255);
    ALLEGRO_BITMAP  * trawa   = al_load_bitmap("media/trawa.jpg" );/// Wczytywanie obrazka
    ALLEGRO_BITMAP  * krowa   = al_load_bitmap( "media/Krowa.png" );
    ALLEGRO_SAMPLE  * krowaMu = al_load_sample( "media/mu.ogg" );
    ALLEGRO_SAMPLE  * piesHau = al_load_sample( "media/hau.ogg" );

    /// kolor przezroczystości gdy brak go w obrazku(wybór dowolnego koloru)
    /// al_convert_mask_to_alpha(krowa, al_map_rgb(255,0,255) );

    al_play_sample(krowaMu , 1.0, 0.0,1.0,ALLEGRO_PLAYMODE_ONCE,NULL); /// tylko raz
    al_play_sample(piesHau, 1.0, 0.0,1.0,ALLEGRO_PLAYMODE_LOOP,NULL);  /// powtarzaj
    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(okno));
    ALLEGRO_EVENT ev;
    double timer = al_current_time(); int nrKlatki = 0;

    while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_keyboard_state(&klawiatura);
        al_get_next_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE){return 0;}

        al_clear_to_color(al_map_rgb(0,255,0));//kolor okna
        al_draw_bitmap (trawa,0,0,0);//Pozycja obrazka
        if ( al_current_time() >= timer+0.3){if ( ++nrKlatki >=8 ) nrKlatki = 0;timer = al_current_time();}
        al_draw_bitmap_region( krowa, 96*nrKlatki, 0, 96, 96, 50, 50, 0 );

        al_flip_display();
        al_rest(0.02);//pauza
    }
    al_destroy_display(okno);
    al_destroy_bitmap (krowa);
    al_destroy_bitmap (trawa);
    al_destroy_sample(krowaMu);
    al_destroy_sample(piesHau);
    al_uninstall_audio();
    return 0;
}
