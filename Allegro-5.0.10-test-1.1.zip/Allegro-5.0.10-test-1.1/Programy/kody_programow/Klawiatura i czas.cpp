#include <allegro5/allegro.h>
#include <allegro5/allegro_font.h>

int szer=320,wys=240,rozm=40;
int main()
{
    al_init();
    al_install_keyboard();
    al_init_font_addon();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_DISPLAY *okno = al_create_display( szer, wys);
    al_set_window_title( okno,"Allegro5 klawiatura i czas");
    ALLEGRO_BITMAP *kwadrat = al_create_bitmap(rozm,rozm);
    ALLEGRO_FONT * font8 = al_create_builtin_font();
    al_set_target_bitmap(kwadrat);
    al_clear_to_color(al_map_rgb(200,20,0));
    al_set_target_bitmap(al_get_backbuffer(okno));
    int x=140,y=100;
    double czas = al_get_time();
    while( !al_key_down( &klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_keyboard_state(&klawiatura);
        if ( al_get_time() > czas + 0.005)
        {
            if ( al_key_down(&klawiatura, ALLEGRO_KEY_RIGHT ) && x  <  szer-rozm) x=x+1 ;
            if ( al_key_down(&klawiatura, ALLEGRO_KEY_LEFT  ) && x  >          0) x=x-1 ;
            if ( al_key_down(&klawiatura, ALLEGRO_KEY_DOWN  ) && y  <  wys -rozm) y=y+1 ;
            if ( al_key_down(&klawiatura, ALLEGRO_KEY_UP    ) && y  >          0) y=y-1 ;
            czas = al_get_time();
        }
        al_clear_to_color(al_map_rgb_f(0.5,0.5,0.5));
        al_draw_bitmap (kwadrat,x,y,0);
        al_draw_textf(font8,al_map_rgb(255,255,0), 10, 10,0,"x=%3d , y=%3d",x,y);
        al_flip_display();
        al_rest(0.001);
    }
    al_destroy_bitmap(kwadrat);
    al_destroy_display(okno);
    return 0;
}
