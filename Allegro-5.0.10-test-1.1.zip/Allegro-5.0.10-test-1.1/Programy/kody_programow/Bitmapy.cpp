// Gabes
#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
int main()
{
    al_init();
    al_install_keyboard();
    al_init_image_addon();
    ALLEGRO_KEYBOARD_STATE klawiatura;
    ALLEGRO_DISPLAY *okno    = al_create_display(640, 480);
    al_set_window_title(okno,"Bitmapy");
    ALLEGRO_BITMAP  *bitmapa = al_load_bitmap( "media/domek.png" );//Wczytywanie obrazka
    //kolor przezroczystości gdy brak go w obrazku(wybór dowolnego koloru)
    //al_convert_mask_to_alpha( bitmapa, al_map_rgb(255,0,255) );
    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(okno));
    ALLEGRO_EVENT event;
    while(!al_key_down(&klawiatura, ALLEGRO_KEY_ESCAPE))
    {
        al_get_next_event(event_queue, &event);
        if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) return 0;
        al_get_keyboard_state(&klawiatura);
        al_clear_to_color(al_map_rgb(128,128,128));//kolor okna

        al_draw_pixel( 5, 5,al_map_rgb(255,255,255));
        al_draw_bitmap (bitmapa, 10, 10, 0);
        al_draw_scaled_bitmap(bitmapa, 15, 10, 90, 90, 150, 10, 128, 128, 1);
        al_draw_rotated_bitmap(bitmapa, 64, 64, 370, 74, 3.14/4, 0);
        al_draw_bitmap_region(bitmapa, 64, 0, 64, 64, 520, 60, 0);
        al_draw_scaled_rotated_bitmap(bitmapa, 64, 64, 90, 225, 0.8, 1.2, 3.14/3, 0);
        al_draw_tinted_bitmap(bitmapa,al_map_rgba_f (1.0, 1.0, 1.0, 0.5), 160, 130, 1);
        al_draw_tinted_scaled_bitmap(bitmapa, al_map_rgba_f (0.5,0.5,0.0,0.4), 10, 20, 100, 80, 300, 150, 100, 100, 0);
        al_draw_tinted_bitmap_region(bitmapa, al_map_rgba_f (0.8,0.2,0.8,0.2), 0, 20, 128, 80, 450, 160, 0);
        al_draw_tinted_rotated_bitmap (bitmapa, al_map_rgba_f (1.0, 1.0, 0.0, 0.5), 64, 64, 90, 350, 1.2, 0);
        al_draw_tinted_scaled_rotated_bitmap(bitmapa, al_map_rgba_f (1.0, 1.0, 1.0, 0.6), 64, 64, 310, 350, 1.5, 1.5, 1.1, 0);
        al_draw_tinted_scaled_rotated_bitmap_region(bitmapa,10,10,110,110, al_map_rgba_f (1.0, 1.0, 1.0, 0.6), 64, 64, 480, 360, 1.9,1.9, 1.4, 0);
        al_flip_display();
        al_rest(0.001);//pauza
    }
    al_save_bitmap("ekran.png",al_get_backbuffer(okno)); // zrzut ekranu do formatu png.
    al_save_bitmap("zapis.bmp",bitmapa); //  zapis nastąpi przy zamykaniu programu
    al_save_bitmap("zapis.png",bitmapa); //  klawiszem escape, a nie X.
    al_save_bitmap("zapis.jpg",bitmapa);
    al_save_bitmap("zapis.pcx",bitmapa);
    al_save_bitmap("zapis.tga",bitmapa);
    al_destroy_display(okno);
    al_destroy_bitmap (bitmapa);
    return 0;
}
