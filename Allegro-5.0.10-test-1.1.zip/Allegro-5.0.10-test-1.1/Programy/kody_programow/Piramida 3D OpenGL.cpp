#include <allegro5/allegro.h>
#include <allegro5/allegro_opengl.h>

GLfloat xrot,yrot,zrot;

void DrawGLScene()
{
    glClearColor(0.5, 0.5, 0.5, 0.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-2,2, -2,2, -10,10);
    glTranslatef(0.0f,0.0f,-2.0f);
    glRotatef(xrot,1.0f,0.0f,0.0f);
    glRotatef(yrot,0.0f,1.0f,0.0f);
    glRotatef(zrot,0.0f,0.0f,1.0f);
    glBegin(GL_TRIANGLES);
     glColor3f(1.0f,0.0f,0.0f);glVertex3f( 0.0f, 1.0f, 0.0f);
     glColor3f(0.0f,1.0f,0.0f);glVertex3f(-1.0f,-1.0f, 1.0f);
     glColor3f(0.0f,0.0f,1.0f);glVertex3f( 1.0f,-1.0f, 1.0f);
     glColor3f(1.0f,0.0f,0.0f);glVertex3f( 0.0f, 1.0f, 0.0f);
     glColor3f(0.0f,0.0f,1.0f);glVertex3f( 1.0f,-1.0f, 1.0f);
     glColor3f(0.0f,1.0f,0.0f);glVertex3f( 1.0f,-1.0f,-1.0f);
     glColor3f(1.0f,0.0f,0.0f);glVertex3f( 0.0f, 1.0f, 0.0f);
     glColor3f(0.0f,1.0f,0.0f);glVertex3f( 1.0f,-1.0f,-1.0f);
     glColor3f(0.0f,0.0f,1.0f);glVertex3f(-1.0f,-1.0f,-1.0f);
     glColor3f(1.0f,0.0f,0.0f);glVertex3f( 0.0f, 1.0f, 0.0f);
     glColor3f(0.0f,0.0f,1.0f);glVertex3f(-1.0f,-1.0f,-1.0f);
     glColor3f(0.0f,1.0f,0.0f);glVertex3f(-1.0f,-1.0f, 1.0f);
    glEnd();
     xrot+=0.6f; yrot+=0.4f; zrot+=0.8f;
}

int main()
 {
    al_init();
    al_set_new_display_flags(ALLEGRO_WINDOWED | ALLEGRO_OPENGL);
    ALLEGRO_DISPLAY * display = al_create_display(600, 600);
    ALLEGRO_EVENT_QUEUE *event_queue = al_create_event_queue();
    al_register_event_source(event_queue, al_get_display_event_source(display));
    ALLEGRO_EVENT ev;
    glEnable(GL_DEPTH_TEST);

    while(1)
    {
        al_get_next_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { return 0; }
        DrawGLScene();
        al_flip_display();
    }
    al_destroy_display(display);
    al_destroy_event_queue(event_queue);
    return 0;
 }
